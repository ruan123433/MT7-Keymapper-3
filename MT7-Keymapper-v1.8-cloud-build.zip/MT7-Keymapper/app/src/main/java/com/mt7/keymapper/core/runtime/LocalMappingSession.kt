package com.mt7.keymapper.core.runtime

import com.mt7.keymapper.core.activation.BackendStatus
import com.mt7.keymapper.core.mapping.FireButtonController
import com.mt7.keymapper.core.mapping.FireButtonSnapshot
import com.mt7.keymapper.core.mapping.FireMode
import com.mt7.keymapper.core.mapping.JoystickSettings
import com.mt7.keymapper.core.mapping.JoystickTransform
import com.mt7.keymapper.core.mapping.JoystickVector
import com.mt7.keymapper.core.mapping.PointerDelta
import com.mt7.keymapper.core.mapping.PointerTransform
import com.mt7.keymapper.core.mapping.VisionSettings

/**
 * Coordinates the in-app mapping simulation. All events are explicitly supplied
 * by the app's test UI; this class never captures system input or injects events.
 */
class LocalMappingSession {
    private val runtime = MappingRuntime(PointerTransform())
    private val joystickTransform = JoystickTransform()
    private val fireController = FireButtonController()

    @Synchronized
    fun start(backendStatus: BackendStatus): RuntimeSnapshot {
        runtime.selectBackend(backendStatus)
        return runtime.start()
    }

    @Synchronized
    fun pause(): RuntimeSnapshot {
        fireController.reset()
        return runtime.pause()
    }

    @Synchronized
    fun resume(): RuntimeSnapshot = runtime.resume()

    @Synchronized
    fun stop(): RuntimeSnapshot {
        fireController.reset()
        return runtime.stop()
    }

    @Synchronized
    fun snapshot(): RuntimeSnapshot = runtime.snapshot()

    @Synchronized
    fun processPointer(delta: PointerDelta, settings: VisionSettings): PointerDelta? =
        runtime.process(delta, settings)

    @Synchronized
    fun processJoystick(input: JoystickVector, settings: JoystickSettings): JoystickVector? {
        if (runtime.snapshot().state != RuntimeState.READY) return null
        return joystickTransform.apply(input, settings)
    }

    @Synchronized
    fun setFireMode(mode: FireMode): FireButtonSnapshot = fireController.setMode(mode)

    @Synchronized
    fun activateFire(): FireButtonSnapshot =
        if (runtime.snapshot().state == RuntimeState.READY) fireController.activate()
        else fireController.reset()

    @Synchronized
    fun releaseFire(): FireButtonSnapshot = fireController.release()

    @Synchronized
    fun resetFire(): FireButtonSnapshot = fireController.reset()

    @Synchronized
    fun fireSnapshot(): FireButtonSnapshot = fireController.snapshot()
}
