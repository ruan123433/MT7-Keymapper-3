package com.mt7.keymapper.core.mapping

/** Configuration model for the vision editor. It does not perform system input injection. */
data class VisionSettings(
    val sensitivityX: Float = 1.0f,
    val sensitivityY: Float = 1.0f,
    val pollingRateHz: Int = DEFAULT_POLLING_RATE_HZ,
    val accelerationProtection: Boolean = true
) {
    init {
        require(sensitivityX.isFinite() && sensitivityX in MIN_SENSITIVITY..MAX_SENSITIVITY)
        require(sensitivityY.isFinite() && sensitivityY in MIN_SENSITIVITY..MAX_SENSITIVITY)
        require(pollingRateHz in SUPPORTED_POLLING_RATES)
    }

    companion object {
        const val MIN_SENSITIVITY = 0.05f
        const val MAX_SENSITIVITY = 10.0f
        const val DEFAULT_POLLING_RATE_HZ = 250
        val SUPPORTED_POLLING_RATES = setOf(125, 250, 500, 1000)
    }
}
