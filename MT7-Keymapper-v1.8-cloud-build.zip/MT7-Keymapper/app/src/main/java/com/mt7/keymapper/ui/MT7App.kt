package com.mt7.keymapper.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.mt7.keymapper.core.activation.ActivationRepository
import com.mt7.keymapper.core.mapping.MappingProfile

private val Navy = Color(0xFF07111F)
private val Panel = Color(0xFF0D1B2B)
private val Blue = Color(0xFF1597FF)
private val Muted = Color(0xFF9CB0C7)

@Composable
fun MT7App(activationRepository: ActivationRepository) {
    val profiles = remember {
        listOf(
            MappingProfile("general", "Perfil geral"),
            MappingProfile("game", "Jogo de exemplo"),
            MappingProfile("desktop", "Aplicativo de exemplo")
        )
    }
    val shizuku = remember { activationRepository.inspectShizuku() }
    val root = remember { activationRepository.inspectRootPlaceholder() }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Navy,
            surface = Panel,
            primary = Blue,
            onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        Scaffold(containerColor = Navy) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(18.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("MT7", color = Blue, style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Black)
                        Text("KEYMAPPER", color = Color.White, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text("Precisão total. Controle absoluto.", color = Muted)
                    }
                }
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("Central de controle", color = Blue, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                            Text("Configure teclado, mouse e controles em um só lugar.", color = Muted)
                            Button(onClick = { /* Editor será implementado na próxima etapa. */ }) {
                                Text("Abrir editor")
                            }
                        }
                    }
                }
                item {
                    Text("Ativação híbrida", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                }
                item { BackendCard("Android", "Disponível", true, "Funções locais do aplicativo") }
                item { BackendCard("Shizuku", if (shizuku.available) "Conectado" else "Não conectado", shizuku.available, shizuku.detail) }
                item { BackendCard("Root", "Em desenvolvimento", false, root.detail) }
                item {
                    Text("Perfis", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                }
                items(profiles) { profile ->
                    Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                        Row(
                            Modifier.fillMaxWidth().padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(profile.name, fontWeight = FontWeight.SemiBold)
                                Text("Sensibilidade X ${profile.sensitivityX} • Y ${profile.sensitivityY}", color = Muted)
                            }
                            Text("EDITAR", color = Blue, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                item {
                    Text("MT7 v0.1.0 • Android 10+", color = Muted, style = MaterialTheme.typography.labelSmall)
                }
            }
        }
    }
}

@Composable
private fun BackendCard(title: String, status: String, active: Boolean, detail: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Text(title, fontWeight = FontWeight.Bold)
                Text(status, color = if (active) Color(0xFF35D07F) else Blue, style = MaterialTheme.typography.labelMedium)
            }
            Text(detail, color = Muted, style = MaterialTheme.typography.bodySmall)
        }
    }
}
