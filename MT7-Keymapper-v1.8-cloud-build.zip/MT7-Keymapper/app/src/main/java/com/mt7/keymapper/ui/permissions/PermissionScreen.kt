package com.mt7.keymapper.ui.permissions

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.mt7.keymapper.core.permissions.PermissionItem
import com.mt7.keymapper.core.permissions.PermissionState

@Composable
fun PermissionScreen(
    items: List<PermissionItem>,
    onOpen: (PermissionItem) -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier.fillMaxSize().padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Central de Permissões", style = MaterialTheme.typography.headlineSmall)
            Text(
                "O MT7 solicita somente os acessos necessários para os recursos que você escolher.",
                color = Color(0xFF9CB0C7)
            )
        }
        items(items, key = { it.id }) { item ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0D1B2B))
            ) {
                Column(
                    Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(item.title, modifier = Modifier.weight(1f))
                        Text(
                            when {
                                item.granted -> "ATIVADA"
                                item.state == PermissionState.REQUIRED -> "NECESSÁRIA"
                                else -> "OPCIONAL"
                            },
                            color = if (item.granted) Color(0xFF35D07F) else Color(0xFF1597FF)
                        )
                    }
                    Text(item.description, color = Color(0xFF9CB0C7))
                    if (item.action != null) {
                        Button(onClick = { onOpen(item) }) { Text("Abrir configurações") }
                    }
                }
            }
        }
    }
}
