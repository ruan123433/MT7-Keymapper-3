package com.mt7.keymapper.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat

/** Foreground lifecycle service. Input injection is intentionally not implemented yet. */
class MT7InputService : Service() {
    private var floatingBall: FloatingBallController? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification())
        floatingBall = FloatingBallController(this) { stopSelf() }.also { it.show() }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_PAUSE -> floatingBall?.setPaused(true)
            ACTION_RESUME -> floatingBall?.setPaused(false)
            ACTION_STOP -> stopSelf()
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        floatingBall?.hide()
        floatingBall = null
        super.onDestroy()
    }

    private fun buildNotification(): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentTitle("MT7 Keymapper")
            .setContentText("Serviço ativo. Injeção de entrada ainda não implementada.")
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Serviço MT7", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    companion object {
        const val CHANNEL_ID = "mt7_input_service"
        const val NOTIFICATION_ID = 7001
        const val ACTION_PAUSE = "com.mt7.keymapper.action.PAUSE"
        const val ACTION_RESUME = "com.mt7.keymapper.action.RESUME"
        const val ACTION_STOP = "com.mt7.keymapper.action.STOP"
    }
}
