package com.mt7.keymapper.core.mapping

data class MappingProfile(
    val id: String,
    val name: String,
    val sensitivityX: Float = 1.0f,
    val sensitivityY: Float = 1.0f,
    val acceleration: Float = 0.0f,
    val smoothing: Float = 0.0f,
    val joystickSensitivityX: Float = 1.0f,
    val joystickSensitivityY: Float = 1.0f,
    val joystickDeadzone: Float = 0.08f,
    val fireMode: FireMode = FireMode.TAP,
    val joystickPositionX: Float = 0.18f,
    val joystickPositionY: Float = 0.78f,
    val viewPositionX: Float = 0.72f,
    val viewPositionY: Float = 0.48f,
    val firePositionX: Float = 0.86f,
    val firePositionY: Float = 0.72f
) {
    init {
        require(sensitivityX in 0.05f..10.0f)
        require(sensitivityY in 0.05f..10.0f)
        require(acceleration in 0.0f..3.0f)
        require(smoothing in 0.0f..1.0f)
        require(joystickSensitivityX in 0.1f..2.0f)
        require(joystickSensitivityY in 0.1f..2.0f)
        require(joystickDeadzone in 0.0f..0.5f)
        require(joystickPositionX in 0.0f..1.0f && joystickPositionY in 0.0f..1.0f)
        require(viewPositionX in 0.0f..1.0f && viewPositionY in 0.0f..1.0f)
        require(firePositionX in 0.0f..1.0f && firePositionY in 0.0f..1.0f)
    }
}
