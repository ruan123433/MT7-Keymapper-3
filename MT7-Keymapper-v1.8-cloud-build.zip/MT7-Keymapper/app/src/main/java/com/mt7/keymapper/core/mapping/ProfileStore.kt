package com.mt7.keymapper.core.mapping

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Persists user-created mapping profiles locally in app-private preferences.
 */
class ProfileStore(context: Context) {
    private val prefs = context.getSharedPreferences("mt7_profiles", Context.MODE_PRIVATE)

    fun loadAll(): List<MappingProfile> {
        val raw = prefs.getString(KEY_PROFILES, null) ?: return listOf(defaultProfile())
        return runCatching {
            val array = JSONArray(raw)
            buildList {
                for (i in 0 until array.length()) {
                    val item = array.getJSONObject(i)
                    add(
                        MappingProfile(
                            id = item.getString("id"),
                            name = item.getString("name"),
                            sensitivityX = item.getDouble("x").toFloat(),
                            sensitivityY = item.getDouble("y").toFloat(),
                            acceleration = item.optDouble("acceleration", 0.0).toFloat(),
                            smoothing = item.optDouble("smoothing", 0.0).toFloat(),
                            joystickSensitivityX = item.optDouble("joyX", 1.0).toFloat(),
                            joystickSensitivityY = item.optDouble("joyY", 1.0).toFloat(),
                            joystickDeadzone = item.optDouble("joyDeadzone", 0.08).toFloat(),
                            fireMode = runCatching { FireMode.valueOf(item.optString("fireMode", "TAP")) }.getOrDefault(FireMode.TAP),
                            joystickPositionX = item.optDouble("joyPosX", 0.18).toFloat(),
                            joystickPositionY = item.optDouble("joyPosY", 0.78).toFloat(),
                            viewPositionX = item.optDouble("viewPosX", 0.72).toFloat(),
                            viewPositionY = item.optDouble("viewPosY", 0.48).toFloat(),
                            firePositionX = item.optDouble("firePosX", 0.86).toFloat(),
                            firePositionY = item.optDouble("firePosY", 0.72).toFloat()
                        )
                    )
                }
            }.ifEmpty { listOf(defaultProfile()) }
        }.getOrElse { listOf(defaultProfile()) }
    }

    fun save(profile: MappingProfile): Boolean {
        val profiles = loadAll().filterNot { it.id == profile.id }.toMutableList()
        profiles.add(profile)
        val array = JSONArray()
        profiles.forEach { p ->
            array.put(
                JSONObject()
                    .put("id", p.id)
                    .put("name", p.name)
                    .put("x", p.sensitivityX.toDouble())
                    .put("y", p.sensitivityY.toDouble())
                    .put("acceleration", p.acceleration.toDouble())
                    .put("smoothing", p.smoothing.toDouble())
                    .put("joyX", p.joystickSensitivityX.toDouble())
                    .put("joyY", p.joystickSensitivityY.toDouble())
                    .put("joyDeadzone", p.joystickDeadzone.toDouble())
                    .put("fireMode", p.fireMode.name)
                    .put("joyPosX", p.joystickPositionX.toDouble())
                    .put("joyPosY", p.joystickPositionY.toDouble())
                    .put("viewPosX", p.viewPositionX.toDouble())
                    .put("viewPosY", p.viewPositionY.toDouble())
                    .put("firePosX", p.firePositionX.toDouble())
                    .put("firePosY", p.firePositionY.toDouble())
            )
        }
        return prefs.edit().putString(KEY_PROFILES, array.toString()).commit()
    }

    fun delete(id: String): Boolean {
        val remaining = loadAll().filterNot { it.id == id }
        val array = JSONArray()
        remaining.forEach { p ->
            array.put(
                JSONObject().put("id", p.id).put("name", p.name)
                    .put("x", p.sensitivityX.toDouble()).put("y", p.sensitivityY.toDouble())
                    .put("acceleration", p.acceleration.toDouble()).put("smoothing", p.smoothing.toDouble())
                    .put("joyX", p.joystickSensitivityX.toDouble())
                    .put("joyY", p.joystickSensitivityY.toDouble())
                    .put("joyDeadzone", p.joystickDeadzone.toDouble())
                    .put("fireMode", p.fireMode.name)
                    .put("joyPosX", p.joystickPositionX.toDouble())
                    .put("joyPosY", p.joystickPositionY.toDouble())
                    .put("viewPosX", p.viewPositionX.toDouble())
                    .put("viewPosY", p.viewPositionY.toDouble())
                    .put("firePosX", p.firePositionX.toDouble())
                    .put("firePosY", p.firePositionY.toDouble())
            )
        }
        return prefs.edit().putString(KEY_PROFILES, array.toString()).commit()
    }

    private fun defaultProfile() = MappingProfile(id = "default", name = "Padrão")

    private companion object { const val KEY_PROFILES = "profiles_json" }
}
