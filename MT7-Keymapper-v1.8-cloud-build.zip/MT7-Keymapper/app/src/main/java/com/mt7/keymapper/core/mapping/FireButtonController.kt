package com.mt7.keymapper.core.mapping

/** Interaction style used by the local fire-button state simulator. */
enum class FireMode {
    TAP,
    HOLD,
    TOGGLE
}

enum class FireTransition {
    PRESSED,
    RELEASED
}

data class FireButtonSnapshot(
    val mode: FireMode,
    val isPressed: Boolean,
    val transitionCount: Long,
    val lastTransition: FireTransition?
)

/**
 * Models button state locally. It deliberately has no Android input or game integration.
 * TAP emits one down/up pair, HOLD stays down until release(), and TOGGLE flips on activate().
 */
class FireButtonController(initialMode: FireMode = FireMode.TAP) {
    private var mode: FireMode = initialMode
    private var pressed = false
    private var transitions = 0L
    private var lastTransition: FireTransition? = null

    fun snapshot(): FireButtonSnapshot = FireButtonSnapshot(
        mode = mode,
        isPressed = pressed,
        transitionCount = transitions,
        lastTransition = lastTransition
    )

    fun setMode(newMode: FireMode): FireButtonSnapshot {
        if (newMode != mode) {
            mode = newMode
            transitionTo(false)
        }
        return snapshot()
    }

    fun activate(): FireButtonSnapshot {
        when (mode) {
            FireMode.TAP -> {
                transitionTo(true)
                transitionTo(false)
            }
            FireMode.HOLD -> transitionTo(true)
            FireMode.TOGGLE -> transitionTo(!pressed)
        }
        return snapshot()
    }

    fun release(): FireButtonSnapshot {
        if (mode == FireMode.HOLD) transitionTo(false)
        return snapshot()
    }

    /** Resets the simulator to released, useful when stopping a local test session. */
    fun reset(): FireButtonSnapshot {
        transitionTo(false)
        return snapshot()
    }

    private fun transitionTo(newPressed: Boolean) {
        if (pressed == newPressed) return
        pressed = newPressed
        transitions += 1
        lastTransition = if (pressed) FireTransition.PRESSED else FireTransition.RELEASED
    }
}
