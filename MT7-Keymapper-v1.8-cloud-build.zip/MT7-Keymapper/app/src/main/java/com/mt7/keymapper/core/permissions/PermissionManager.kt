package com.mt7.keymapper.core.permissions

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.content.ContextCompat

enum class PermissionState { GRANTED, REQUIRED, OPTIONAL }

data class PermissionItem(
    val id: String,
    val title: String,
    val description: String,
    val state: PermissionState,
    val granted: Boolean,
    val action: Intent? = null
)

class PermissionManager(private val context: Context) {
    fun getItems(): List<PermissionItem> {
        val overlayGranted = Settings.canDrawOverlays(context)
        val notificationGranted = Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(
                context, Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED

        return buildList {
            add(
                PermissionItem(
                    id = "overlay",
                    title = "Sobreposição de tela",
                    description = "Exibe a bolinha flutuante sobre outros aplicativos.",
                    state = PermissionState.REQUIRED,
                    granted = overlayGranted,
                    action = if (!overlayGranted) Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:${context.packageName}")
                    ) else null
                )
            )
            add(
                PermissionItem(
                    id = "notifications",
                    title = "Notificações",
                    description = "Mostra o estado do serviço MT7. Obrigatória para a experiência completa em Android 13+.",
                    state = PermissionState.OPTIONAL,
                    granted = notificationGranted,
                    action = if (Build.VERSION.SDK_INT >= 33 && !notificationGranted) {
                        Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(
                            Settings.EXTRA_APP_PACKAGE, context.packageName
                        )
                    } else null
                )
            )
            add(
                PermissionItem(
                    id = "shizuku",
                    title = "Shizuku",
                    description = "Backend opcional. Requer Shizuku instalado, iniciado e autorização concedida.",
                    state = PermissionState.OPTIONAL,
                    granted = false
                )
            )
            add(
                PermissionItem(
                    id = "root",
                    title = "Root",
                    description = "Backend opcional. Só estará disponível em dispositivos com root autorizado.",
                    state = PermissionState.OPTIONAL,
                    granted = false
                )
            )
        }
    }

    fun openAction(item: PermissionItem) {
        item.action?.let { context.startActivity(it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    }
}
