package com.mt7.keymapper.core.activation

import java.io.File

/**
 * Root status probe only.
 *
 * This checks common su locations without executing su, requesting a
 * superuser prompt, changing system files, or running privileged commands.
 * Finding an su binary does not prove that root access is granted.
 */
class RootBackend : ActivationBackend {
    override val kind = BackendKind.ROOT

    override suspend fun inspect(): BackendStatus {
        val candidates = listOf(
            "/system/bin/su",
            "/system/xbin/su",
            "/sbin/su",
            "/system_ext/bin/su",
            "/vendor/bin/su"
        )
        val found = candidates.firstOrNull { path ->
            runCatching { File(path).exists() }.getOrDefault(false)
        }

        return if (found != null) {
            BackendStatus(
                kind,
                false,
                "Binário su encontrado em $found, mas a autorização Root ainda não foi confirmada. Nenhum comando privilegiado foi executado."
            )
        } else {
            BackendStatus(
                kind,
                false,
                "Nenhum binário su conhecido foi encontrado. Root indisponível ou não detectável por esta verificação."
            )
        }
    }
}
