package com.mt7.keymapper.ui.devices

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.mt7.keymapper.core.devices.InputDeviceDescriptor
import com.mt7.keymapper.core.devices.InputDeviceInspector

@Composable
fun InputDeviceDiagnosticsPanel(modifier: Modifier = Modifier) {
    var devices by remember { mutableStateOf(InputDeviceInspector.scan()) }

    Column(
        modifier = modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text("Dispositivos de entrada", style = MaterialTheme.typography.titleLarge, color = Color(0xFF1597FF))
                Text(
                    "${devices.size} dispositivo(s) visível(is) para o MT7",
                    color = Color(0xFF9CB0C7),
                    style = MaterialTheme.typography.bodySmall
                )
            }
            Button(onClick = { devices = InputDeviceInspector.scan() }) {
                Text("Atualizar")
            }
        }

        if (devices.isEmpty()) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0D1B2B))
            ) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Nenhum dispositivo listado", color = Color.White)
                    Text(
                        "Conecte um mouse, teclado ou controle e toque em Atualizar. Alguns dispositivos podem não ser expostos pelo Android a aplicativos comuns.",
                        color = Color(0xFF9CB0C7),
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(devices, key = { it.id }) { device -> DeviceCard(device) }
            }
        }

        Text(
            "Diagnóstico somente de leitura. Esta tela não captura teclas/movimentos, não injeta eventos e não altera jogos.",
            color = Color(0xFF9CB0C7),
            style = MaterialTheme.typography.bodySmall
        )
    }
}

@Composable
private fun DeviceCard(device: InputDeviceDescriptor) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0D1B2B))
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            Text(device.name, color = Color.White, style = MaterialTheme.typography.titleMedium)
            Text(device.kind, color = Color(0xFF1597FF), style = MaterialTheme.typography.labelLarge)
            Text("Fontes: ${device.sources.joinToString(" • ")}", color = Color(0xFFCAD7E5))
            Text("ID Android: ${device.id}  •  ${if (device.isVirtual) "Virtual" else "Não virtual"}", color = Color(0xFF9CB0C7), style = MaterialTheme.typography.bodySmall)
            Text("Teclado: ${device.keyboardType}", color = Color(0xFF9CB0C7), style = MaterialTheme.typography.bodySmall)
            val vendor = device.vendorId.takeIf { it != 0 }?.toString() ?: "N/D"
            val product = device.productId.takeIf { it != 0 }?.toString() ?: "N/D"
            Text("Vendor ID: $vendor  •  Product ID: $product", color = Color(0xFF9CB0C7), style = MaterialTheme.typography.bodySmall)
        }
    }
}
