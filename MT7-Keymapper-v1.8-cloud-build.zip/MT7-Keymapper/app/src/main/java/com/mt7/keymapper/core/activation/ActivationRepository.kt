package com.mt7.keymapper.core.activation

class ActivationRepository(
    private val shizukuBackend: ShizukuBackend = ShizukuBackend(),
    private val rootBackend: RootBackend = RootBackend()
) {
    suspend fun inspectShizuku(): BackendStatus = shizukuBackend.inspect()

    suspend fun inspectRoot(): BackendStatus = rootBackend.inspect()

    fun inspectAndroid(): BackendStatus = BackendStatus(
        BackendKind.ANDROID,
        available = true,
        detail = "Recursos locais do aplicativo disponíveis."
    )

    // Synchronous compatibility helpers for existing screens.
    fun inspectShizukuNow(): BackendStatus = runCatching {
        val binderAlive = rikka.shizuku.Shizuku.pingBinder()
        if (!binderAlive) BackendStatus(
            BackendKind.SHIZUKU, false,
            "Shizuku desconectado. Inicie o Shizuku e atualize o estado."
        ) else {
            val granted = rikka.shizuku.Shizuku.checkSelfPermission() ==
                android.content.pm.PackageManager.PERMISSION_GRANTED
            BackendStatus(
                BackendKind.SHIZUKU,
                granted,
                if (granted) "Shizuku conectado e autorização do MT7 concedida."
                else "Shizuku conectado, mas falta conceder autorização ao MT7."
            )
        }
    }.getOrElse {
        BackendStatus(BackendKind.SHIZUKU, false, "Não foi possível consultar o Shizuku: ${it.message}")
    }

    fun inspectRootNow(): BackendStatus = runCatching {
        val candidates = listOf("/system/bin/su", "/system/xbin/su", "/sbin/su", "/system_ext/bin/su", "/vendor/bin/su")
        val found = candidates.firstOrNull { java.io.File(it).exists() }
        BackendStatus(
            BackendKind.ROOT,
            false,
            if (found != null) "su encontrado em $found; autorização Root ainda não confirmada."
            else "Nenhum binário su conhecido foi encontrado."
        )
    }.getOrElse {
        BackendStatus(BackendKind.ROOT, false, "Não foi possível verificar Root: ${it.message}")
    }
}
