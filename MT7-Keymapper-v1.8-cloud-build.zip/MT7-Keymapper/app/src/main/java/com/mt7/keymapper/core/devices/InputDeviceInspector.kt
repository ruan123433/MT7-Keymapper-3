package com.mt7.keymapper.core.devices

import android.view.InputDevice

/**
 * Read-only inventory of input devices exposed to this application by Android.
 * This does not read raw events, capture input globally, or inject events.
 */
object InputDeviceInspector {
    fun scan(): List<InputDeviceDescriptor> = InputDevice.getDeviceIds().asSequence()
        .mapNotNull { id ->
            val device = InputDevice.getDevice(id) ?: return@mapNotNull null
            val sources = sourceLabels(
                keyboard = device.hasSource(InputDevice.SOURCE_KEYBOARD),
                mouse = device.hasSource(InputDevice.SOURCE_MOUSE),
                gamepad = device.hasSource(InputDevice.SOURCE_GAMEPAD),
                joystick = device.hasSource(InputDevice.SOURCE_JOYSTICK),
                dpad = device.hasSource(InputDevice.SOURCE_DPAD),
                touchscreen = device.hasSource(InputDevice.SOURCE_TOUCHSCREEN),
                stylus = device.hasSource(InputDevice.SOURCE_STYLUS),
                trackball = device.hasSource(InputDevice.SOURCE_TRACKBALL)
            )
            InputDeviceDescriptor(
                id = device.id,
                name = device.name.ifBlank { "Dispositivo sem nome" },
                kind = classify(sources),
                sources = sources,
                vendorId = device.vendorId,
                productId = device.productId,
                keyboardType = keyboardTypeLabel(device.keyboardType),
                isVirtual = device.isVirtual
            )
        }
        .sortedWith(compareBy<InputDeviceDescriptor>({ it.kind }, { it.name.lowercase() }, { it.id })).toList()

    /** Pure helper kept separate so the classification can be unit-tested. */
    fun sourceLabels(
        keyboard: Boolean,
        mouse: Boolean,
        gamepad: Boolean,
        joystick: Boolean,
        dpad: Boolean,
        touchscreen: Boolean,
        stylus: Boolean,
        trackball: Boolean
    ): List<String> = buildList {
        if (keyboard) add("Teclado")
        if (mouse) add("Mouse")
        if (gamepad) add("Gamepad")
        if (joystick) add("Joystick")
        if (dpad) add("Direcional")
        if (touchscreen) add("Tela touch")
        if (stylus) add("Caneta")
        if (trackball) add("Trackball")
        if (isEmpty()) add("Fonte não identificada")
    }

    fun classify(sources: List<String>): String {
        val hasPointer = "Mouse" in sources || "Tela touch" in sources || "Caneta" in sources
        val hasButtons = "Teclado" in sources || "Gamepad" in sources || "Direcional" in sources
        val hasAnalog = "Joystick" in sources || "Trackball" in sources
        return when {
            "Mouse" in sources && hasButtons -> "Mouse + teclas/controle"
            hasPointer && (hasButtons || hasAnalog) -> "Controle combinado"
            "Gamepad" in sources || "Joystick" in sources -> "Controle"
            "Mouse" in sources -> "Mouse"
            "Teclado" in sources -> "Teclado"
            "Tela touch" in sources -> "Tela touch"
            hasAnalog -> "Entrada analógica"
            else -> "Outro dispositivo"
        }
    }

    private fun keyboardTypeLabel(type: Int): String = when (type) {
        InputDevice.KEYBOARD_TYPE_NONE -> "Sem teclado"
        InputDevice.KEYBOARD_TYPE_NON_ALPHABETIC -> "Teclas não alfabéticas"
        InputDevice.KEYBOARD_TYPE_ALPHABETIC -> "Teclado alfabético"
        else -> "Tipo desconhecido"
    }
}

data class InputDeviceDescriptor(
    val id: Int,
    val name: String,
    val kind: String,
    val sources: List<String>,
    val vendorId: Int,
    val productId: Int,
    val keyboardType: String,
    val isVirtual: Boolean
)
