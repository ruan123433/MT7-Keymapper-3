#include <jni.h>
#include <cmath>
#include <string>

extern "C"
JNIEXPORT jstring JNICALL
Java_com_mt7_keymapper_nativebridge_NativeBridge_nativeVersion(JNIEnv* env, jobject) {
    const std::string version = "MT7 Vision Engine 0.6.0";
    return env->NewStringUTF(version.c_str());
}

extern "C"
JNIEXPORT jfloatArray JNICALL
Java_com_mt7_keymapper_nativebridge_NativeBridge_transformDelta(
        JNIEnv* env,
        jobject,
        jfloat dx,
        jfloat dy,
        jfloat sensitivityX,
        jfloat sensitivityY,
        jboolean accelerationProtection) {

    // Reject non-finite input and invalid gains rather than propagating NaN/Inf.
    if (!std::isfinite(dx) || !std::isfinite(dy) ||
        !std::isfinite(sensitivityX) || !std::isfinite(sensitivityY) ||
        sensitivityX < 0.05f || sensitivityX > 10.0f ||
        sensitivityY < 0.05f || sensitivityY > 10.0f) {
        jfloat zero[2] = {0.0f, 0.0f};
        jfloatArray result = env->NewFloatArray(2);
        if (result != nullptr) env->SetFloatArrayRegion(result, 0, 2, zero);
        return result;
    }

    // v0.6 deliberately uses a linear transform. With protection enabled,
    // no speed-dependent acceleration/gain is applied.
    (void) accelerationProtection;
    jfloat values[2] = {dx * sensitivityX, dy * sensitivityY};

    jfloatArray result = env->NewFloatArray(2);
    if (result != nullptr) env->SetFloatArrayRegion(result, 0, 2, values);
    return result;
}
