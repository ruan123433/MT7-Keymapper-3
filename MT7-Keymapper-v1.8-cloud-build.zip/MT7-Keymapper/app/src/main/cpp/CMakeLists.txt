cmake_minimum_required(VERSION 3.22.1)
project(mt7native LANGUAGES CXX)

add_library(mt7native SHARED native_bridge.cpp)

find_library(log-lib log)
target_link_libraries(mt7native ${log-lib})
target_compile_features(mt7native PRIVATE cxx_std_17)
